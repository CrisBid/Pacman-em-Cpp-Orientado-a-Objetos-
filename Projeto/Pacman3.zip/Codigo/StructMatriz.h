#pragma once
#include <iostream>

#ifndef STRUCTMATRIZ_H
#define STRUCTMATRIZ_H

using namespace std;

	struct sMatriz
	{
		int dados_matriz[62][56];
		int matriz_largura;
		int matriz_altura;
	};

#endif